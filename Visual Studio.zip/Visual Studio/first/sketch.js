console.log("LOADED");

let cewb;

// Setup is run once
function setup(){
    createCanvas(400,400);
    cewb = new q3();
}

// Draw is run repeatedly i.e: thread 
function draw(){
    background(40,140,140);
    cewb.move();
    cewb.show();
}

class q3{
  constructor(){
    this.x = 200;
    this.y = 150;
  }

  move(){
    this.x += random(-1,1);
    this.y += random(-1,1);
  }

  show(){
    rect(this.x,this.y,40,40);
  }
}