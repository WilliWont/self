class q3{
  this.x =0;
  this.y = 0;
}