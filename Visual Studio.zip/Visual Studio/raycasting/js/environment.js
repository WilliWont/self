class Environment{
  constructor(gravity, wind){
    this.g = createVector(0, gravity);
    this.w = wind;
  }
}